<?php
return [
    'host' => 'localhost',
    'user' => 'root',
    'password' => '1234', // '<yourpassword>',
    'database' => 'emensawerbeseite'
];
