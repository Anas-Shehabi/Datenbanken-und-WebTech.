<?php

class anmeldungController {


    public function index(RequestData $rd) {

        return view('anmeldung', []);
    }



}
