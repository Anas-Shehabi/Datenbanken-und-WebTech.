create
    definer = root@localhost procedure anzahlanmeldungen(IN userid int)
BEGIN
    UPDATE
        benutzer
    SET
        anzahlanmeldungen=anzahlanmeldungen+1
    WHERE
            id = userid;
END;

