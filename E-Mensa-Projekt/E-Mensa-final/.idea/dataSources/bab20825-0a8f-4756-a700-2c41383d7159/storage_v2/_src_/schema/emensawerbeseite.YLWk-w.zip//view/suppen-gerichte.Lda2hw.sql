create view `suppen-gerichte` as
select `emensawerbeseite`.`gericht`.`id`           AS `id`,
       `emensawerbeseite`.`gericht`.`name`         AS `name`,
       `emensawerbeseite`.`gericht`.`beschreibung` AS `beschreibung`,
       `emensawerbeseite`.`gericht`.`erfasst_am`   AS `erfasst_am`,
       `emensawerbeseite`.`gericht`.`vegan`        AS `vegan`,
       `emensawerbeseite`.`gericht`.`vegetarisch`  AS `vegetarisch`,
       `emensawerbeseite`.`gericht`.`preis_intern` AS `preis_intern`,
       `emensawerbeseite`.`gericht`.`preis_extern` AS `preis_extern`
from `emensawerbeseite`.`gericht`
where `emensawerbeseite`.`gericht`.`name` like '%suppe%';

