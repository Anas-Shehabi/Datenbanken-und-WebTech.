create view view_anmeldungen as
select `emensawerbeseite`.`benutzer`.`id`                AS `id`,
       `emensawerbeseite`.`benutzer`.`email`             AS `email`,
       `emensawerbeseite`.`benutzer`.`passwort`          AS `passwort`,
       `emensawerbeseite`.`benutzer`.`admin`             AS `admin`,
       `emensawerbeseite`.`benutzer`.`anzahlfehler`      AS `anzahlfehler`,
       `emensawerbeseite`.`benutzer`.`anzahlanmeldungen` AS `anzahlanmeldungen`,
       `emensawerbeseite`.`benutzer`.`letzteanmeldung`   AS `letzteanmeldung`,
       `emensawerbeseite`.`benutzer`.`letzterfehler`     AS `letzterfehler`
from `emensawerbeseite`.`benutzer`
order by `emensawerbeseite`.`benutzer`.`anzahlanmeldungen` desc;

