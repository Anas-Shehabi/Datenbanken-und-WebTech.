create view view_kategoriegerichte_vegetarisch as
select `emensawerbeseite`.`gericht`.`name` AS `name`, `emensawerbeseite`.`kategorie`.`name` AS `kategorie`
from ((`emensawerbeseite`.`gericht` left join `emensawerbeseite`.`gericht_hat_kategorie` on (
        `emensawerbeseite`.`gericht_hat_kategorie`.`gericht_id` = `emensawerbeseite`.`gericht`.`id`))
         left join `emensawerbeseite`.`kategorie`
                   on (`emensawerbeseite`.`kategorie`.`id` = `emensawerbeseite`.`gericht_hat_kategorie`.`kategorie_id`))
where `emensawerbeseite`.`gericht`.`vegetarisch` = 1
   or `emensawerbeseite`.`gericht_hat_kategorie`.`gericht_id` is null;

